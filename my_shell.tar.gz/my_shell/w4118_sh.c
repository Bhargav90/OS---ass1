#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>

#define max_size 32
#define max_tok 10

int path_size = 10;
int path_num;
int tok_num;
char **tok;
char **path;
char *cur_path;

int execution();
int attach_path(char *);

int main()
{
	int c, j, i = 0, pipe_no = 0;
	int pid;
	int *pipefd;
	int cur_size = max_size;
	int status;
	char *input = malloc(cur_size);
	tok_num  = 0;
	path_num = 0;
	pipefd   = malloc(sizeof(int) * 4);
	tok      = malloc(sizeof(char *) * max_tok);
	path     = malloc(sizeof(char *) * path_size);

	printf("$");
	while ((c = getchar()) != EOF) {
		if (c == '|') {
			if (i > 0) {
				input[i] = '\0';
				tok[tok_num] = malloc(sizeof(char) * strlen(input) + 1);
				strcpy(tok[tok_num], input);
				tok[++tok_num] = NULL;
			}
			if (tok_num == 0) {
				fprintf(stderr, "error: No input before pipe");
				printf("$");
			} else {
				pipe_no++;
				pipefd = realloc(pipefd, (sizeof(int) * (pipe_no*2)));
				pipe(pipefd+(2*pipe_no - 2));
				pid = fork();
				if (pid == 0) {
					if (pipe_no > 1) {
						if (dup2(pipefd[2*pipe_no-4], 0) < 0)
							fprintf(stderr, "error: %s", strerror(errno));
					} else
						close(0);
					if (dup2(pipefd[2*pipe_no - 1], 1) < 0)
						fprintf(stderr, "error: %s", strerror(errno));
					if (tok[0][0] != '/')
						attach_path(tok[0]);
					tok[tok_num] = NULL;
					execv(tok[0], tok);
					fprintf(stderr, "error: %s\n", strerror(errno));
					exit(0);
				} else if (pid == -1)
					printf("error: didn't fork");
				close(pipefd[pipe_no*2-1]);
				wait(&status);
				i = 0;
				for (j = 0; j < tok_num; j++)
					if (tok[j] != NULL)
						free(tok[j]);
				tok_num = 0;
				cur_size = max_size;
				input = realloc(input, sizeof(char)*max_size);
				memset(input, '\0', max_size);
			}
		} else if (c == '\n' && pipe_no > 0) {
			if (i > 0) {
				input[i] = '\0';
				tok[tok_num] = malloc(sizeof(char) * strlen(input) + 1);
				strcpy(tok[tok_num], input);
				tok[++tok_num] = NULL;
			}
			if (tok_num == 0) {
				fprintf(stderr, "error: no arguments for last pipe\n");
				printf("$");
				continue;
			}
			pid = fork();
			if (pid == 0) {
				dup2(pipefd[2*pipe_no-2], 0);
				for (j = 0; j < 2*pipe_no; j++)
					close(pipefd[j]);
				tok[tok_num] = NULL;
				if (tok[0][0] != '/')
					attach_path(tok[0]);
				execv(tok[0], tok);
				fprintf(stderr, "error: fin_pip %d:%s\n", pipe_no, strerror(errno));
				exit(0);
			} else if (pid < 0)
				printf("error: didnt fork");
			wait(&status);
			for (j = 0; j < 2*pipe_no; j++)
				close(pipefd[j]);
			pipe_no = 0;
			i = 0;
			for (j = 0; j < tok_num; j++)
				if (tok[j] != NULL)
					free(tok[j]);
			tok_num = 0;
			cur_size = max_size;
			input = realloc(input, sizeof(char)*max_size);
			memset(input, '\0', max_size);
			printf("$");

		} else if (c == '\n' && pipe_no == 0) {
			if (i > 0) {
				input[i] = '\0';
				tok[tok_num] = malloc(sizeof(char) * strlen(input) + 1);
				strcpy(tok[tok_num], input);
				tok[++tok_num] = NULL;
			}
			if (tok_num > 0 && execution() == 0)
				break;
			for (j = 0; j < tok_num; j++) {
				if (tok[j] != NULL)
					free(tok[j]);
			}
			printf("\n");
			tok_num = 0;
			cur_size = max_size;
			i = 0;
			input = realloc(input, sizeof(char) * max_size);
			memset(input, '\0', max_size);
			printf("$");
		} else if (c == ' ' || c == '\t') {
			if (i > 0) {
				input[i] = '\0';
				tok[tok_num] = malloc(sizeof(char) * strlen(input) + 1);
				strcpy(tok[tok_num++], input);
			}
			i = 0;
			cur_size = max_size;
			input = realloc(input, sizeof(char) * max_size);
			memset(input, '\0', max_size);
		} else {
			input[i++] = c;
		}
		if (i == cur_size) {
			cur_size += max_size;
			input = realloc(input, cur_size);
		}
		if (tok_num == 10) {
			printf("error: Token overflow");
			break;
		}
	}
	for (j = 0; j < path_num; j++) {
		if (path[j] != NULL)
			free(path[j]);
	}
	if (input != NULL)
		free(input);
	return 0;
}

int execution()
{
	int pid;
	int status;
	int i, j;
	if (strcmp("exit", tok[0]) == 0)
		return 0;
	else if (strcmp("cd", tok[0]) == 0) {
		if (tok_num == 2) {
			if (chdir(tok[1]) == -1)
				fprintf(stderr, "error: %s", strerror(errno));
		} else
			printf("error: cd invalid arguments");
		return 1;

	} else if (strcmp("path", tok[0]) == 0) {
		if (path_num == path_size) {
			path_size++;
			path = realloc(path, sizeof(char *) * path_size);
		}
		if (tok_num == 1)
			for (j = 0; j < path_num; j++)
				printf("%s\n", path[j]);

		else if (tok[1] == NULL || tok[2] == NULL || tok_num > 3)
			printf("error: invalid arguments for path");
		else if (strcmp(tok[1], "+") == 0) {
			for (i = 0; i < path_num; i++)
				if (strcmp(path[i], tok[2]) == 0)
					return 1;
			path[path_num] = malloc(strlen(tok[2])+1);
			strcpy(path[path_num++], tok[2]);
		} else if (strcmp(tok[1], "-") == 0) {
			for (i = 0; i < path_num; i++) {
				if (strcmp(path[i], tok[2]) == 0) {
					path_num--;
					if (path[i] != NULL)
						free(path[i]);
					path[i] = path[path_num];
					path[path_num] = NULL;
				} else
					fprintf(stderr, "error: '%s' not found\n", tok[2]);
			}
		}
		return 1;
	} else {
		if (tok[0][0] != '/')
			attach_path(tok[0]);
		pid = fork();
		if (pid == 0) {
			tok[tok_num] = NULL;
			execve(tok[0], tok, NULL);
			fprintf(stderr, "error: %s", strerror(errno));
			return 1;
		} else if (pid > 0)
			wait(&status);
		else
			fprintf(stderr, "error: %s", strerror(errno));
	}
	return 1;
}

int attach_path(char *cmd)
{
	char tmp[128];
	int i, fd;
	for (i = 0; path[i] != NULL; i++) {
		memset(tmp, '\0', 128);
		strncpy(tmp, path[i], strlen(path[i]));
		if (tmp[strlen(tmp)-1] != '/')
			strcat(tmp, "/");
		strncat(tmp, cmd, strlen(cmd));
		fd = open(tmp, O_RDONLY);
		if (fd >= 0) {
			close(fd);
			cmd = realloc(cmd, strlen(tmp));
			strncpy(cmd, tmp, strlen(tmp));
			return 0;
		}
	}
	return 0;
}
